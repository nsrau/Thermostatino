A simple arduino library for the Itead Nextion HMI.

Nextion LCD Touchscreen Tutorial for Arduino

http://openhardware.gridshield.net/home/nextion-lcd-getting-started-for-arduino

Nextion LCD Touchscreen Library Functions

http://openhardware.gridshield.net/home/nextion-example-code-functions
